# python-flask-restapi
Example Project on how to develop RESTful API with Flask and Python
