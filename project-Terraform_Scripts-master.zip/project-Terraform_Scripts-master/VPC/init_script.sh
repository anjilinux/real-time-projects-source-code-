#!/bin/bash
sudo yum update -y
sudo yum install wget unzip -y
