# jekins-ansible-dynimc-inventory
